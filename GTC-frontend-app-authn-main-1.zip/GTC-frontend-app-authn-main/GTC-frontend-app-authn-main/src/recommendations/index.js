/* eslint-disable import/prefer-default-export */
export { default as RecommendationsPage } from './RecommendationsPage';
