npx tailwindcss -i ./src/tailwind.css -o ./src/main.css --watch
